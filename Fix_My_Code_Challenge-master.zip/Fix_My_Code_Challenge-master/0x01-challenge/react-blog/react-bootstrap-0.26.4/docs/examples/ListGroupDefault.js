const listgroupInstance = (
  <ListGroup>
    <ListGroupItem>Item 1</ListGroupItem>
    <ListGroupItem>Item 2</ListGroupItem>
    <ListGroupItem>...</ListGroupItem>
  </ListGroup>
);

React.render(listgroupInstance, mountNode);
