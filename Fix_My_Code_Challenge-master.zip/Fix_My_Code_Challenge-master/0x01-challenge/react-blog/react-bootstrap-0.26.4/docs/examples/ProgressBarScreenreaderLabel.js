const progressInstance = (
  <ProgressBar now={60} label="%(percent)s%" srOnly />
);

React.render(progressInstance, mountNode);
